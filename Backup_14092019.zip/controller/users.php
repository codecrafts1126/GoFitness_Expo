<?php

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){

    require '../admin/functions.php';	
    require '../views/header.view.php';
    require '../views/navbar.view.php';    
    
    $errors = '';   
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	}
    
    $users = get_all_users($connect);
     if (empty($users)){
         $errors .='<div style="padding: 0px 15px;">No data found</div>';
    }
    
    $users_total = number_users($connect);
    
    require '../views/users.view.php';
    require '../views/footer.view.php';
        
}
else {
	header('Location: ' . SITE_URL . '/controller/login.php');		
}
?>