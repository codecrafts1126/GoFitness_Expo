<?php

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';	
    require '../views/header.view.php';
    require '../views/navbar.view.php';    
    
    $errors = '';   
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    $subscriptions = get_all_subscriptions($connect);
     if (empty($subscriptions)){
         $errors .='<div style="padding: 0px 15px;">No data found</div>';
    }
    
    $subscriptions_total = number_subscriptions($connect);
    
    require '../views/subscriptions.view.php';
    require '../views/footer.view.php';
        
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>