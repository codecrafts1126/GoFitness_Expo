<?php

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';	
    require '../views/header.view.php';
    require '../views/navbar.view.php';    
    
    $errors = '';   
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    $classes = get_all_classes($connect);
     if (empty($classes)){
         $errors .='<div style="padding: 0px 15px;">No data found</div>';
    }
    
    $classes_total = number_classes($connect);
    
    require '../views/classes.view.php';
    require '../views/footer.view.php';
        
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>