<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php'; 
    
    $errors = '';
    
    $connect = connect($database);
    if(!$connect){
    	header('Location: ' . SITE_URL . '/controller/error.php');
    	} 
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    	
    	$class_name = cleardata($_POST['class_name']);
    	$class_details = $_POST['class_details'];
    	$class_status = $_POST['class_status'];
    	$class_image = $_FILES['class_image']['tmp_name'];
    	
    	$imagefile = explode(".", $_FILES["class_image"]["name"]);
    	$renamefile = round(microtime(true)) . '.' . end($imagefile);
    	$class_image_upload = '../' . $items_config['images_folder'].'classes/';
    	move_uploaded_file($class_image, $class_image_upload . 'class_img_' . $renamefile);
    	
    	$statment = $connect->prepare(
    		'INSERT INTO TABLE_CLASS (class_name, class_details, class_image, class_status) VALUES (:class_name, :class_details, :class_image, :class_status)'
    		);
    		
    	$statment->execute(array(
    		':class_name' => $class_name,
    		':class_details' => $class_details,
    		':class_image' => 'class_img_' . $renamefile,
    		':class_status' => $class_status
    		));
    
    	header('Location:' . SITE_URL . '/controller/classes.php');
    	
    }
    
    require '../views/new.class.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>