<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php';
    
    $connect = connect($database);
    if(!$connect){
        
    	header ('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    	$id = $_POST['id'];
    	$user_name = cleardata($_POST['user_name']);
    	$user_id = cleardata($_POST['user_id']);
    	$user_phone = cleardata($_POST['user_phone']);
    	$user_email = cleardata($_POST['user_email']);
    	$user_sex = $_POST['user_sex'];
    	$birthday = $_POST['birthday'];
    	$user_weight = $_POST['user_weight'];
    	$user_height = $_POST['user_height'];
    	$user_image_save = $_POST['user_image_save'];
    	$user_image = $_FILES['user_image'];
    	$user_status = $_POST['user_status'];
    	
    	if (empty($user_image['name'])) {
    		$user_image = $user_image_save;
    	}
    	else{
			$imagefile = explode(".", $_FILES["user_image"]["name"]);
			$renamefile = round(microtime(true)) . '.' . end($imagefile);
		    $user_image_upload = '../' . $items_config['images_folder'].'users/';
		    move_uploaded_file($_FILES['user_image']['tmp_name'], $user_image_upload . 'user_img_' . $renamefile);
		    $user_image = 'user_img_' . $renamefile;
    	}
    	
    	$statment = $connect->prepare('UPDATE TABLE_USER SET name=:user_name, email=:user_email, phone=:user_phone, user_id=:user_id, user_weight=:user_weight, user_height=:user_height, user_sex=:user_sex, user_status=:user_status, user_birthdate=Date(:birthday), user_image=:user_image WHERE objid=:id');
    	
    	$statment->execute(array(
    	    
    	    ':id' => $id,
    		':user_name' => $user_name,
    		':user_id' => $user_id,
    		':user_phone' => $user_phone,
    		':user_email' => $user_email,
    		':user_sex' => $user_sex,
    		':birthday' => $birthday,
    		':user_weight' => $user_weight,
    		':user_height' => $user_height,
    		':user_image' => $user_image,
    		':user_status' => $user_status
    		));
    	
    	header('Location:' . SITE_URL . '/controller/users.php');
    
    } 
    else{
    
        $id = id_user($_GET['id']);
        
        if(empty($id)){
    	    header('Location: home.php');
    	}
    
        $user = get_user_per_id($connect, $id);
        
        if (!$user){
            header('Location: ' . SITE_URL . '/controller/home.php');
        }
    
        $user = $user['0'];
    }
    
    require '../views/edit.user.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>