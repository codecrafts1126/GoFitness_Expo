<?php

require '../admin/config.php';
$title_page = 'Error';
require '../views/header.view.php';       
require '../views/error.view.php';
require '../views/footer.view.php';

?>