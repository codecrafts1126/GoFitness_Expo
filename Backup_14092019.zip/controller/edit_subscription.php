<?php 

session_start();
require '../admin/config.php';

if (isset($_SESSION['username'])){
    
    require '../admin/functions.php';
    require '../views/header.view.php';
    require '../views/navbar.view.php';
    
    $connect = connect($database);
    if(!$connect){
        
    	header ('Location: ' . SITE_URL . '/controller/error.php');
    }
    
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    	$subscription_id = $_POST['subscription_id'];
    	$subscription_name = cleardata($_POST['subscription_name']);
    	$subscription_details = cleardata($_POST['subscription_details']);
    	$subscription_period = $_POST['subscription_period'];
    	$subscription_bank = $_POST['subscription_bank'];
    	$subscription_price = $_POST['subscription_price'];
    	$subscription_status = $_POST['subscription_status'];
    	
    	$statment = $connect->prepare('UPDATE TABLE_SUBSCRIPTION SET subscription_name=:subscription_name, subscription_details=:subscription_details, subscription_status=:subscription_status, subscription_period=:subscription_period, subscription_bank=:subscription_bank, subscription_price=:subscription_price WHERE objid=:subscription_id');
    	
    	$statment->execute(array(
    
    		':subscription_id' => $subscription_id,
    		':subscription_name' => $subscription_name,
    		':subscription_details' => $subscription_details,
    		':subscription_period' => $subscription_period,
    		':subscription_bank' => $subscription_bank,
    		':subscription_price' => $subscription_price,
    		':subscription_status' => $subscription_status
    		));
    	
    	header('Location:' . SITE_URL . '/controller/subscriptions.php');
    
    } 
    else{
    
        $subscription_id = id_subscription($_GET['subscription_id']);
        
        if(empty($subscription_id)){
    	    header('Location: home.php');
    	}
    
        $subscription = get_subscription_per_id($connect, $subscription_id);
        
        if (!$subscription){
            header('Location: ' . SITE_URL . '/controller/home.php');
        }
    
        $subscription = $subscription['0'];
    }
    
    require '../views/edit.subscription.view.php';
    require '../views/footer.view.php';
}
else {
		header('Location: ' . SITE_URL . '/controller/login.php');		
}

?>