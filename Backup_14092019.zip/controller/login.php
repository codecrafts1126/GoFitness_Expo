<?php 

session_start();

require '../admin/config.php';
require '../admin/functions.php';

if (isset($_SESSION['username'])){
    
    header('Location: ' . SITE_URL . '/controller/home.php');
}

$connect = connect($database);
if(!$connect){
	header('Location: ' . SITE_URL . '/controller/error.php');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST'){
    
	$email = filter_var(strtolower($_POST['email']), FILTER_SANITIZE_STRING);
	$password = $_POST['password'];
	$_SESSION['lang'] = $_POST['lang'];
	
	$errors = '';
	
	try{        
            $connect;
            
    }
    catch (PDOException $e){
            
            echo "Error: ." . $e->getMessage();   
    }
       
   	$sql = 'SELECT * FROM TABLE_USER WHERE (email=:email OR user_id=:email) AND user_status > 0 AND priv_class > 0';
	$query = $connect->prepare($sql);
	$query->execute(array('email' => $email));
	$data = $query->fetchObject();
	$salt = $data->salt;
	$db_encrypted_password = $data->encrypted_password;
	
	if (verifyHash(trim($password.$salt), $db_encrypted_password)) {
	    
		 $_SESSION['username'] = $data->unique_id;
		 header('Location: ' . SITE_URL . '/controller/home.php');
	}
	else{
			 
		$errors .='Incorrect login data';
	}
}

$title_page = 'Sign In';
require '../views/header.view.php';
require '../views/login.view.php';
require '../views/footer.view.php';

?>