<?php 

require '../views/sidebar.view.php';

?>