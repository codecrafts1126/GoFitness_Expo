<?php require'sidebar.php'; ?>

<!--Page Container--> 
<section class="page-container">
    <div class="page-content-wrapper">

        

        <!--Main Content-->

 <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                                        <div class="block-heading d-flex align-items-center title-pages">
                    <h5 class="text-truncate"><?=_EDIT_CLASS?></h5>
                </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-block mb-4">

<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">

<div class="form-row">
  <div class="form-group col-md-12">
    <div class="block col-md-12" style="padding-bottom: 35px">

   <input type="hidden" value="<?php echo $class['objid']; ?>" name="class_id">
   <label class="control-label"><?=_NAME?></label>
   <input type="text" value="<?php echo $class['class_name']; ?>" placeholder="" name="class_name" class="form-control" required="">
   
   <label class="control-label"><?=_DETAILS?></label>
   <textarea value="" name="class_details" class="form-control" id="class_details"><?php echo $class['class_details']; ?></textarea>
   
   <label class="control-label"><?=_ACTIVE?></label>
   <div class="row">
                        <div class="col-sm-1">

                        <?php $in = '1';

if (strpos($in, $class['class_status']) !== false) {
    echo '<div class="radio radio-success"> <input type="radio" name="class_status" id="radio5" value="'.$class['class_status'].'" checked=""> <label for="radio5">'._YES.'</label> </div>';
}else{
  echo '<div class="radio radio-success"> <input type="radio" name="class_status" id="radio5" value="'. $in .'"><label for="radio5">'._YES.'</label> </div>';
}
                         ?>
                        </div>

                        <div class="col-sm-1">

                        <?php 
$out = '0';

if (strpos($out, $class['class_status']) !== false) {
    echo '<div class="radio radio-danger"> <input type="radio" name="class_status" id="radio6" value="0" checked=""> <label for="radio6">'._NO.'</label> </div>';
}else{
  echo '<div class="radio radio-danger"> <input type="radio" name="class_status" id="radio6" value="'. $out .'"> <label for="radio6">'._NO.'</label> </div>';
}
                         ?>
                        </div>

                    </div>
   
   <label><?=_IMAGE?></label>
    <div class="new-image" id="image-preview" style="background: url(../images/classes/<?php echo $class['class_image'] ?>);background-size: cover; background-position: center;">
      <label for="image-upload" id="image-label"><?=_CHOOSE_FILE?></label>
      <input type="hidden" value="<?php echo $class['exercise_image']; ?>" name="class_image_save">
      <input type="file" name="class_image" id="image-upload" />
    </div>
    
    <span class="text-danger recomendedsize"><?=_RECOMMENDED_SIZE?><b><?=_IMAGE_SIZE?></b> </span>
    
   <br />
   <br />
   <div class="action-button">
   <input type="submit" name="update" value="<?=_UPDATE?>" class="btn btn-embossed btn-primary" onclick="this.value='<?=_UPDATING?>';">
   </div>

   <?php if( !empty($errors)): ?>
   
		<div class="alert alert-danger animated fadeIn" role="alert" style="margin-top: 20px; margin-bottom: 0; text-transform: uppercase; font-size: 11px; text-align: center;">

		    <?php echo $errors; ?>

		</div>
		
   <?php endif; ?>
							
</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</section>