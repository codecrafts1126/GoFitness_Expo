<?php require'sidebar.php'; ?>

<!--Page Container--> 
<section class="page-container">
    <div class="page-content-wrapper">

        

        <!--Main Content-->

 <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                                        <div class="block-heading d-flex align-items-center title-pages">
                    <h5 class="text-truncate"><?=_NEW_PLACE?></h5>
                </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-block mb-4">

<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">


<div class="form-row">
  <div class="form-group col-md-12">
    <div class="block col-md-12" style="padding-bottom: 35px">

   <label class="control-label"><?=_NAME?></label>
   <input type="text" value="" placeholder="Title" name="place_name" class="form-control" required="">
   
   <label class="control-label"><?=_LATITUDE?></label>
   <input type="text" value="" name="place_latitude" id="place_latitude" class="form-control" required>
   
   <label class="control-label"><?=_LONGITUDE?></label>
   <input type="text" value="" name="place_longitude" id="place_longitude" class="form-control" required>
   
   <label class="control-label"><?=_PICK_LAT_LON?></label>
    <div>
        <div id="map" style="height: 400px; width: 100%; "></div>
    </div>
    
    <script type="text/javascript">
    var map;
    
    function initMap() {
        
        var latitude = 32.69177189181271;
        var longitude = 35.29992741899798;
        
        var myLatLng = {lat: latitude, lng: longitude};
        
        map = new google.maps.Map(document.getElementById('map'), {
          center: myLatLng,
          zoom: 14,
          disableDoubleClickZoom: true
        });
        
        var marker = new google.maps.Marker({ 
          position: myLatLng, 
          draggable: true,
          map: map,
          animation: google.maps.Animation.DROP,
        }); 
        
        google.maps.event.addListener(marker,'dragend',function(event) {
            
            document.getElementById('place_latitude').value = event.latLng.lat();
            document.getElementById('place_longitude').value =  event.latLng.lng();
        });
        
        google.maps.event.addListener(map,'click',function(event) {                
            document.getElementById('place_latitude').value = event.latLng.lat();
            document.getElementById('place_longitude').value =  event.latLng.lng();
        });
        
        google.maps.event.addListener(map, 'click', function(event) {
            
            placeMarker(event.latLng);
        });
        
        function placeMarker(location) {

            if (marker == undefined){
                marker = new google.maps.Marker({
                    position: location,
                    map: map, 
                    draggable: true,
                    animation: google.maps.Animation.DROP,
                });
            }
            else{
                marker.setPosition(location);
            }
            //map.setCenter(location);
        }
    }
    </script>
    
    <label class="control-label"><?=_ACTIVE?></label>
   <div class="row">
        <div class="col-sm-1">
            <div class="radio radio-success"> <input type="radio" name="place_status" id="radio5" checked="" value='1'> <label for="radio5"><?=_YES?></label> </div>
        </div>
        <div class="col-sm-1">
            <div class="radio radio-danger"> <input type="radio" name="place_status" id="radio6" value='0'> <label for="radio6"><?=_NO?></label> </div>
        </div>
   </div>
   
   <br />
   <br />
   
   <div class="action-button">
   <input type="submit" name="save" value="<?=_ADD?>" class="btn btn-embossed btn-primary">
   <input type="reset" name="reset" value="<?=RESET?>" class="btn btn-embossed btn-danger">
   </div>

</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
