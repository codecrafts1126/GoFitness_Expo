<?php require'sidebar.php'; ?>

<!--Page Container--> 
<section class="page-container">
    <div class="page-content-wrapper">

        

        <!--Main Content-->

 <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                                        <div class="block-heading d-flex align-items-center title-pages">
                    <h5 class="text-truncate"><?=_NEW_COACH?></h5>
                </div>
                    </div>

                    <div class="col-md-12">
                        <div class="form-block mb-4">

<form enctype="multipart/form-data" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">


<div class="form-row">
  <div class="form-group col-md-12">
    <div class="block col-md-12" style="padding-bottom: 35px">

   <label class="control-label"><?=_NAME?></label>
   <input type="text" value="" placeholder="Name" name="coach_name" class="form-control" required="">

   <label class="control-label"><?=_DETAILS?></label>
   <textarea value="" name="coach_details" class="form-control" id="coach_details"></textarea>
   
    
   <label class="control-label"><?=_ACTIVE?></label>
   <div class="row">
        <div class="col-sm-1">
            <div class="radio radio-success"> <input type="radio" name="coach_status" id="radio5" checked="" value='1'> <label for="radio5"><?=_YES?></label> </div>
        </div>
        <div class="col-sm-1">
            <div class="radio radio-danger"> <input type="radio" name="coach_status" id="radio6" value='0'> <label for="radio6"><?=_NO?></label> </div>
        </div>
   </div>
   
   <label><?=_IMAGE?></label>
   <div class="new-image" id="image-preview">
      <label for="image-upload" id="image-label"><?=_CHOOSE_FILE?></label>
      <input type="file" name="coach_image" id="image-upload" required="" />
   </div>
    
   <span class="text-danger recomendedsize"><?=_RECOMMENDED_SIZE?><b><?=_PROFILE_IMAGE_SIZE?></b> </span>
    
   <br />
   <br />
   
   <div class="action-button">
   <input type="submit" name="save" value="<?=_ADD?>" class="btn btn-embossed btn-primary">
   <input type="reset" name="reset" value="<?=_RESET?>" class="btn btn-embossed btn-danger">
   </div>

</div>
</div>
</div>
</form>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
