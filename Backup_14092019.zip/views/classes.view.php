<?php require'sidebar.php'; ?>

<script type="text/javascript">
  $(document).ready( function () {
    $('#table_id').DataTable();
} );
</script>

<!--Page Container--> 
<section class="page-container">
    <div class="page-content-wrapper">

        

        <!--Main Content-->

 <div class="content sm-gutter">
            <div class="container-fluid padding-25 sm-padding-10">
                <div class="row">
                    <div class="col-12">
                        <div class="section-title">
                            <h5><?=_CLASSES?></h5>
                        </div>
                    </div>

<div class="col-12">
                        <div class="block table-block mb-4" style="margin-top: 20px;">

                            <div class="row">
                                <div class="table-responsive">
                                    
<table id="table_id" class="table table-striped table-bordered" cellspacing="0" width="100%" style="border-radius: 5px;">
    <thead>
            <tr>
                <th><?=_ID?></th>
                <th><?=_IMAGE?></th>
                <th><?=_NAME?></th>
                <th><?=_ACTIVE?></th>
                <th><?=_ACTIONS?></th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th><?=_ID?></th>
                <th><?=_IMAGE?></th>
                <th><?=_NAME?></th>
                <th><?=_ACTIVE?></th>
                <th><?=_ACTIONS?></th>
            </tr>
        </tfoot>

        <tbody>
        <?php foreach($classes as $class): ?>
            <tr>
                <td><?php echo $class['objid']; ?></td>
                <td width="30px" align="center"><img src="../images/classes/<?php echo $class['class_image']; ?>" style="width: 40px; height: 40px; padding: 2px;"></td>
                <td><?php echo $class['class_name']; ?></td>
                <td class="status">
                    <?php
                    $status = $class['class_status'];
                    if ($status == 1) {
                        echo '<span class="badge badge-pill bg-success">'._YES.'</span>';
                    }else{
                        echo '<span class="badge badge-pill bg-warning">'._NO.'</span>';
                    }
                    ?>
                </td>
                <td>
                <a href="../controller/edit_class.php?class_id=<?php echo $class['objid']; ?>" style="font-size: 14px;color: #000000;"><i class="fa fa-cog"></i></a>
              </td>
            </tr>
        <?php endforeach; ?>

        </tbody>
</table>

</div>
</div>
</div>
</div>
</div>
</div>
</div>
</div>
</section>
