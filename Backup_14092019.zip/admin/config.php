<?php

/* URL PROJECT */

define ('SITE_URL', 'https://zobaba.com/fitness');

/* DATABASE CONFIGURATION */

$database = array(
'host' => 'localhost',
'db' => 'rabialin_fitness',
'user' => 'rabialin_fitness',
'pass' => 'u02pMS(O2baZ'
);

$email_config = array(
'email_address' => 'com.tarbon.springo@gmail.com',
'email_password' => '2l883RbUtx',
'email_subject' => 'Fitness Mailer',
'email_name' => 'Fitness App',
'smtp_host' => 'smtp.gmail.com',
'smtp_port' => '587',
'smtp_encrypt' => 'tls'
);

$items_config = array(
    
    'items_per_page' => '8',
    'images_folder' => 'images/'
);


?>