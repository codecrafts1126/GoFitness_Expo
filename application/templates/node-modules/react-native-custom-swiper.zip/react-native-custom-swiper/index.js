import Swiper from './Swiper';
export default Swiper;
module.exports = Swiper;
